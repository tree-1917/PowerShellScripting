﻿###Pipe Gridview
get-service |out-gridview
get-service |format-table displayname, status, requiredservices |out-gridview
get-service |select-object displayname, status, requiredservices | out-gridview
get-service |select-object * | out-gridview